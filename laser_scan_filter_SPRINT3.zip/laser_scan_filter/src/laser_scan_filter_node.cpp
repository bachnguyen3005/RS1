#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/laser_scan.hpp>
#include <opencv2/opencv.hpp>
#include <vector>
#include <cmath>

class LaserScanFilter : public rclcpp::Node 
{
public:
    LaserScanFilter() : Node("laser_scan_filter_node"){
        // Load the prebuilt map image
        RCLCPP_INFO(this->get_logger(), "Scan to Image Node started.");
        // map_image_ = cv::imread("/home/mapGT.png", cv::IMREAD_COLOR);

        // if (map_image_.empty()) {
        //     RCLCPP_ERROR(this->get_logger(), "Failed to load map image");
        //     return;
        // }

        // // Display the original map
        // cv::imshow("Map", map_image_);
        // cv::waitKey(1);

        // Subscriber to the LaserScan topic
        laser_subscriber_ = this->create_subscription<sensor_msgs::msg::LaserScan>(
            "/scan", 10, std::bind(&LaserScanFilter::laserScanCallback, this, std::placeholders::_1));
        
        
    }

private:
    void laserScanCallback(const sensor_msgs::msg::LaserScan::SharedPtr scan_msg)
    {
        float angle_min = scan_msg->angle_min;
        float angle_increment = scan_msg->angle_increment;
        const auto &ranges = scan_msg->ranges;

        // Sliding window size (adjust as needed)
        const int window_size = 10;
        const float curvature_threshold = 0.15*0.01; // Adjust based on expected curvature of circles

        bool circle_detected = false;
        float circle_x = 0.0, circle_y = 0.0;

        // Iterate through the laser scan ranges, using a sliding window
        for (size_t i = window_size; i < ranges.size() - window_size; ++i)
        {
            // Collect points in a window
            std::vector<float> window_ranges(ranges.begin() + i - window_size, ranges.begin() + i + window_size);
            
            // Check if the points form a circular arc using curvature
            if (isCircularArc(window_ranges, scan_msg->angle_min + i * angle_increment, angle_increment, curvature_threshold))
            {
                // Calculate the center of the circle using average angle
                float angle = angle_min + i * angle_increment;
                circle_x = ranges[i] * std::cos(angle);
                circle_y = ranges[i] * std::sin(angle);
                circle_detected = true;
                break;
            }
        }

        if (circle_detected)
        {
            RCLCPP_INFO(this->get_logger(), "Circle detected at: x = %.2f, y = %.2f", circle_x, circle_y);
        }
        else
        {
            RCLCPP_INFO(this->get_logger(), "No circle detected");
        }
    }

    bool isCircularArc(const std::vector<float>& window_ranges, float start_angle, float angle_increment, float curvature_threshold)
    {
        // Simple curvature check between points in the window
        // Calculate the approximate curvature and see if it remains constant
        for (size_t i = 1; i < window_ranges.size() - 1; ++i)
        {
            float r_prev = window_ranges[i - 1];
            float r_curr = window_ranges[i];
            float r_next = window_ranges[i + 1];

            float angle_prev = start_angle + (i - 1) * angle_increment;
            float angle_next = start_angle + (i + 1) * angle_increment;

            // Calculate distance between consecutive points
            float distance_prev = std::sqrt(r_prev * r_prev + r_curr * r_curr - 2 * r_prev * r_curr * std::cos(angle_increment));
            float distance_next = std::sqrt(r_curr * r_curr + r_next * r_next - 2 * r_curr * r_next * std::cos(angle_increment));

            // Check if the change in distance is small, indicating a curve
            if (std::abs(distance_next - distance_prev) > curvature_threshold)
            {
                return false;  // Not a circle
            }
        }

        return true;  // Circle detected
    }

    rclcpp::Subscription<sensor_msgs::msg::LaserScan>::SharedPtr laser_subscriber_;
    // cv::Mat map_image_;
};

int main(int argc, char* argv[]) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<LaserScanFilter>());
    rclcpp::shutdown();
    return 0;
}
